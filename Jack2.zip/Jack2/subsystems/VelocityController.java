/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc3018.Jack2.subsystems;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.VelocityMeasPeriod;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.SpeedController;

/**
 * Add your docs here.
 */
public class VelocityController implements SpeedController{

    private WPI_TalonSRX controller;

	public VelocityController(WPI_TalonSRX controller) {
		 this.controller=controller;
		 
		 /* "full" output will scale to 11 volts */
		 /*controller.configVoltageCompSaturation(11.0, 10);
		 controller.enableVoltageCompensation(true); /* turn on the voltage compensation feature */
	        
	        /* tweak the voltage bus measurement filter,
	        * default is 32 cells in rolling average (1ms per sample) */
        controller.configVoltageMeasurementFilter(32, 10);
	        
        controller.configSelectedFeedbackSensor(FeedbackDevice.QuadEncoder, 0, 100);
		 controller.configVelocityMeasurementPeriod(VelocityMeasPeriod.Period_100Ms, 50);
		 
		controller.config_kP(0, 1, 100);//PIDindx,value,timeout
		controller.config_kI(0, 0, 100);//PIDindx,value,timeout
        controller.config_kD(0, 20, 100);//PIDindx,value,timeout
        controller.config_kF(0,0.9,100);
        controller.configAllowableClosedloopError(0, 20, 0);

		controller.setSensorPhase(true);
	
	}
    @Override
    public void pidWrite(double output) {

    }

    @Override
    public void set(double speed) {
        controller.set(ControlMode.Velocity, speed*1000);
    }

    @Override
    public double get() {
        return 0;
    }

    @Override
    public void setInverted(boolean isInverted) {

    }

    @Override
    public boolean getInverted() {
        return false;
    }

    @Override
    public void disable() {

    }

    @Override
    public void stopMotor() {

    }

}


package org.usfirst.frc3018.Jack2;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;


public class PistonToSwitch extends Thread{

    DigitalInput magSwitch;
    DoubleSolenoid piston;
    boolean targetSwitchVal;
    public PistonToSwitch(DigitalInput magSwitch,DoubleSolenoid piston,boolean targetSwitchVal){
        this.magSwitch=magSwitch;
        this.piston=piston;
        this.targetSwitchVal=targetSwitchVal;

    }
    @Override
    public void run(){
        while(!(magSwitch.get()==targetSwitchVal)){
            try {
                wait(1);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        piston.set(Value.kOff);
    }

}